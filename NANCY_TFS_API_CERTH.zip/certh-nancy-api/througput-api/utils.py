# -*- coding: utf-8 -*-
"""
Created on Tue Feb 27 10:54:06 2024

@author: loumponias
"""

import numpy as np  

def clean_df(df, intrp):
   
    # check columns with nan values
    col_nan = [df[col].isnull().any() for col in df.columns]

    # find the columns with nan values
    indx_trg = [i for i, x in enumerate(col_nan) if x]
    col_trg= list(df.columns[indx_trg])
    
    # interpolation
    df_new = df.copy()
    df_new[col_trg] = df[col_trg].interpolate(method=intrp)

    # check cases with nan and discard them 
    ls = [df_new[col].isnull() for col in col_trg]
    max_index_nan = [np.max(l[l].index) for l in ls]
    
    if col_trg == []:
        return df_new
    
    else:
        if np.nanmax(max_index_nan) > -1:
            t = int(np.nanmax(max_index_nan))
        else:
            t = -1
        return df_new[t+1:]

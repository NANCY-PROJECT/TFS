# -*- coding: utf-8 -*-
"""
Created on Wed May  1 18:21:42 2024

@author: kosta
"""

from flask import Flask, jsonify, request
import main_fun
import warnings
from flask_cors import CORS

warnings.filterwarnings("ignore")
app = Flask(__name__)
CORS(app)

@app.route('/predict', methods=['POST'])
def predict_attack():
    
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    # Get the list of files
    data_file = request.files.get('file')
    
    # If no files are selected
    if data_file is None:
        return jsonify({'error': 'No files selected'}), 400
    
    step =  request.args.get('step', default=20, type=int)
    if not step:
        return jsonify({'error': 'No step provided'}), 400
    
    results = main_fun.prediction(data_file, step)
    return results

@app.route('/', methods=['GET'])
def index():
    return 'Throughput Prediction'

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
# -*- coding: utf-8 -*-
"""
Created on Wed May  1 15:44:17 2024

@author: kosta
"""
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import load_model
from utils import clean_df

def prediction(data_file, step):   
    # import data
    df = pd.read_csv(data_file)
    
    if df['seq_num'].values[-1] - df['seq_num'].values[-20] == 19: # check if sequence data are provided
        # correct nr_ssRsrq
        df['nr_ssRsrq'] = df['nr_ssRsrq'].mask(df['nr_ssRsrq'] > 0, np.nan)
        
        # normalize 
        scaler_x = MinMaxScaler() 
        df[df.columns[4:-1]] = scaler_x.fit_transform(df[df.columns[4:-1]])
        scaler_y = MinMaxScaler() 
        df[df.columns[-1]] = scaler_y.fit_transform(df[df.columns[-1]][:,np.newaxis])
        
        # interpolation for nan-values
        df_clean = clean_df(df, 'linear')
        
        if df_clean.size >= 24: # checek if there are enough data available
            # moving average MA(5)
            df_clean_ma = df_clean.rolling(window=5).mean() # MA filtering 
            df_clean_ma['seq_num'] = df_clean['seq_num']
            df_clean_ma = df_clean_ma.dropna()    
        
            # de-trend 
            df_clean_ma['d1_thput'] = df_clean_ma['Throughput'].diff()
            df_clean_ma = df_clean_ma.dropna()  
            
            # input data
            x_inp = df_clean_ma[df_clean_ma.columns[1:]].values[-20:,:]
        
            # import model
            model = load_model('predictor.h5')
            y_pred = np.squeeze(model.predict(x_inp[np.newaxis]))
            
            # add trendency
            last_value = x_inp[-1,-2]               
            y_pred = np.cumsum(y_pred)  + last_value
            
            # inverse to original scale
            y_pred = scaler_y.inverse_transform(y_pred[np.newaxis])[0]
            y_pred = y_pred*(y_pred > 0)
            return {"predictions": y_pred.tolist()[:step]}
        
        else:
            return {"predictions": 'There are not enough data available'}

    else:
        return {"predictions": 'Sequence data not available'}


if __name__ == "__main__":
       path = 'C:/Users/loumponias/Documents/eketa/NANCY/Lumos5G-v1.0/regression_per_time_series/api/data/'
       data_path = path  + "data_100.csv"
       results = prediction(data_path) 